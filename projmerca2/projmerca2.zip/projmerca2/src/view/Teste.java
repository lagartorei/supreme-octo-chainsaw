package view;

/*import model.Produto;

public class Teste {

    public static void main(String[] args){
        Produto ps4 = new Produto("Playstation 4", 1798.2);
        Produto xbox = new Produto("xbox360", 2540.0);

        System.out.println(ps4);
        System.out.println(xbox);
    }
}*/